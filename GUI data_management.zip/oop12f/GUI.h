#pragma once
#include <qwidget.h>
#include "service.h"
#include "qlistwidget.h"
#include "qlineedit.h"
#include "qpushbutton.h"
class GUI : public QWidget
{
private:
	service* Service;
	void initGUI();
	QListWidget* footage_widget, *mode_b_widget;
	QLineEdit* title_line, * section_line, * date_line, * acces_count_line, * preview_line, *mode_line, *my_list_location_line;
	QPushButton* add_button, * delete_button, * update_button, * list_button, * set_mode_button, * next_button, * save_button, * filter_button, * mylist_location_button,*mylist_button;
	void populate_list();
	void connect_signals_and_slots();
	int get_selected_index();
	void add_footage();
	void delete_footage();
	void update_footage();
	void set_mode();
	void set_mylist_location();
	void next();
	void save();
	void open_mylist();
	void filter();
public:
	GUI(service* Service);
};

