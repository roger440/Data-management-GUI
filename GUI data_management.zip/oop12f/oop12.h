#pragma once

#include <QtWidgets/QMainWindow>
#include "ui_oop12.h"

class oop12 : public QMainWindow
{
    Q_OBJECT

public:
    oop12(QWidget *parent = Q_NULLPTR);

private:
    Ui::oop12Class ui;
};
