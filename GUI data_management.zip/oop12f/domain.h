#pragma once
#include <string>
#include <fstream>
#include <iostream>
#include <sstream>

#define MAX_STRING_SIZE 25
class date
{
private:
	int day;
	int month;
	int year;
public:
	date(int day, int month, int year);
	date();

	int get_day();
	int get_month();
	int get_year();
};
class footage
{
private:
	friend class istream;
	friend class ostream;
	std::string title;
	std::string section;
	date Date;
	int acces_count;
	std::string preview;

public:
	footage(std::string title, std::string section, date Date, int acces_count, std::string preview);
	footage();
	std::string get_title();
	std::string get_section();
	date get_date();
	int get_acces_count();
	std::string get_preview();
	friend std::istream& operator>>(std::istream& stream, footage& Footage);
	friend std::ostream& operator<<(std::ostream& stream, footage& Footage);

};