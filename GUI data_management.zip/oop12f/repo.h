#pragma once
#include "domain.h"
#include <vector>
typedef footage data_type;


class repo
{
	friend class mylist_repo;
public:
	virtual void add(data_type* Footage)=0;
	virtual void add_to_watchlist(std::string Title)=0;
	virtual void update(std::string title, std::string section, int day, int month, int year, int Acces_count, std::string preview)=0;
	virtual void remove(std::string title)=0;
	virtual void set_file_location(char* file_location)=0;
	virtual std::vector<footage> get_container()=0;
	virtual void write_container_to_file(std::vector<footage> Container)=0;
	virtual void write_watchlist_to_file(std::vector<footage> Watchlist)=0;
	virtual std::vector<footage> get_watchlist()=0;
	virtual void open_mylist()=0;
	virtual void set_myList_location(char* mylistLocation)=0;
	virtual int get_count()=0;

};
class file_repo : public repo
{
private:
	int number_of_footages;
	char file_location[100];
	int watchlist_size;
	char mylistLocation[100];
	char mylistMode[50];
public:
	file_repo();
	void add(data_type* Footage) override;
	void add_to_watchlist(std::string Title) override;
	void update(std::string title, std::string section, int day, int month, int year, int Acces_count, std::string preview) override;
	void remove(std::string title) override;
	void set_file_location(char* file_location) override;
	std::vector<footage> get_container() override;
	void write_container_to_file(std::vector<footage> Container) override;
	void write_watchlist_to_file(std::vector<footage> Watchlist) override;
	std::vector<footage> get_watchlist() override;
	void open_mylist() override;
	void set_myList_location(char* mylistLocation) override;
	int get_count() override;
	void set_mylist_mode(char* mode);
};
class memory_repo : public repo
{
private:
	std::vector <footage> container;
	int watchlist_size;
	char mylistLocation[100];
	char mylistMode[50];
public:
	memory_repo();
	void add_to_watchlist(std::string Title) override;
	void update(std::string title, std::string section, int day, int month, int year, int Acces_count, std::string preview) override;
	void remove(std::string title) override;
	void add(data_type* Footage) override;
	void set_file_location(char* file_location) override
	{
		//nothing special here
	}
	void write_container_to_file(std::vector<footage> Container) override
	{
		//nothing special here
	}
	void write_watchlist_to_file(std::vector<footage> Watchlist) override;
	void open_mylist() override;
	std::vector<footage> get_container() override;
	std::vector<footage> get_watchlist() override;
	void set_myList_location(char* mylistLocation) override;
	void set_mylist_mode(char* mode);
	int get_count() override;
};