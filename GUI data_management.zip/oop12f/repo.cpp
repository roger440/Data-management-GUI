#include "repo.h"
#include <stdio.h>
#include <Windows.h>
#define MAX_CAPACITY 100
#define entity_border_left 9
#define entity_border_right 4
#include "validator.h"
#include <Windows.h>
#include <assert.h>
file_repo::file_repo()
{
	//creates the repo
	this->number_of_footages = 0;
	this->watchlist_size = 0;
	strcpy(this->file_location, "");
	strcpy(this->mylistLocation, "");
}
void file_repo::open_mylist()
{
	if (strcmp(this->mylistMode,"csv")==0)
		ShellExecuteA(NULL, NULL, "notepad.exe", this->mylistLocation, NULL, SW_SHOWNORMAL);
	else
		ShellExecuteA(NULL, NULL, "chrome.exe", this->mylistLocation, NULL, SW_SHOWMAXIMIZED);
}
void file_repo::write_watchlist_to_file(std::vector<footage> Watchlist)
{
	if (strcmp(this->mylistLocation, "") == 0)
		throw RepositoryExceptions("You forgot to enter a myList location");
	else if((strcmp(this->mylistMode,"csv")!=0) && (strcmp(this->mylistMode, "html") != 0))
		throw RepositoryExceptions("Invalid myList location, neither html nor csv");
	if (strcmp(this->mylistMode, "csv") == 0)
	{
		//write in csv format
		std::ofstream write(this->mylistLocation);
		for (auto Footage : Watchlist)
		{
			write << Footage;
		}
		write.close();
	}
	else
	{
		std::ofstream file{ this->mylistLocation };
		file << "<!DOCTYPE html>\n<html>\n<head>\n<title>Footages</title>\n</head><body>\n<table border='1'>\n<tr>\n<td>Title</td>\n<td>Section</td>\n<td>Date</td>\n<td>AccesCount</td>\n<td>Preview</td>\n</tr>\n";
		for (auto Footage : Watchlist) {
			file << "<tr>\n";
			file << "<td>" + Footage.get_title() << "</td>\n";
			file << "<td>" + Footage.get_section() << "</td>\n";
			date Date = Footage.get_date();
			file << "<td>" << Date.get_day() << "-" << Date.get_month() << "-" << Date.get_year() << "</td>\n";
			file << "<td>" << Footage.get_acces_count() << "</td>\n";
			file << "<td>" + Footage.get_preview() << "</td>\n";
			file << "</tr>\n";
		}
		file << "</table>\n";
		file << "</body>\n";
		file << "</hmtl>";

		file.close();
	}
}
void file_repo::add_to_watchlist(std::string Title)
{
	//searches for the specific footage and adds it to the watchlist
	std::vector<footage> Container = this->get_container();
	std::vector<footage> Watchlist = this->get_watchlist();
	bool found = 0;
	for (auto element : Container)
	{
		if (element.get_title() == Title)
		{
			Watchlist.push_back(element);
			this->watchlist_size++;
			found = 1;
		}
	}
	this->write_watchlist_to_file(Watchlist);
	if(!found)
		throw RepositoryExceptions("The footage was not found!");
}


void file_repo::add(data_type* Footage)
{
	//adds a footage to the container and ipdates the file
	std::vector<footage> Container = this->get_container();
	if (strcmp(this->file_location,"") == 0)
		throw RepositoryExceptions("You forgot to enter a file location");
	Container.push_back(*Footage);
	this->number_of_footages++;
	this->write_container_to_file(Container);
}


void file_repo::update(std::string title, std::string section, int day, int month, int year, int Acces_count, std::string preview)
{
	//searches for the specific footage and updates its content
	validator Validator;
	int index = -1;
	bool found = 0;
	std::vector<footage> Container = this->get_container();
	for (auto element : Container)
	{
		index++;
		if (element.get_title() == title)
		{
			found = 1;
			date Date(day, month, year);
			footage Footage(title, section, Date, Acces_count, preview);
			Container.at(index) = Footage;
		}
	}
	write_container_to_file(Container);
	if (!found)
		throw RepositoryExceptions("Element to be updated not found");
}
void file_repo::set_myList_location(char* mylistLocation)
{
	
	strcpy(this->mylistLocation, mylistLocation);
}
void file_repo::remove(std::string title)
{
	//removes the specific footage and updates the file
	validator Validator;
	std::vector<footage> Container = this->get_container();
	int found = 0;
	for (auto element = Container.begin(); element != Container.end();)
	{
		if (element->get_title() == title)
		{
			found = 1;
			element = Container.erase(element);
			this->number_of_footages--;
		}
		else
		{
			element++;
		}
	}
	this->write_container_to_file(Container);
	if (!found)
	{
		throw RepositoryExceptions("Element to be removed not found");
	}
}
void file_repo::set_mylist_mode(char* mode)
{
	strcpy(this->mylistMode, mode);
}
std::vector<footage> file_repo::get_container()
{
	int footage_count = 0;

	//returns the container 
	if (strcmp(this->file_location, "") == 0)
		throw RepositoryExceptions("You forgot to enter a file location");
	std::ifstream read(this->file_location);
	read >> footage_count;
	read.get();
	this->number_of_footages = footage_count;
	std::vector<footage> Container{};
	footage Footage{};
	for (int i = 0; i < footage_count; i++)
	{
		read >> Footage;
		Container.push_back(Footage);
	}
	read.close();
	return Container;
}
std::vector<footage> file_repo::get_watchlist()
{
	//opening the file accordingly
	if (strcmp(this->mylistMode, "csv") == 0)
	{
		//reading the csv file
		std::ifstream read{ this->mylistLocation };

		std::vector <footage> Watchlist;
		int i;
		footage Footage{};
		for (i = 0; i < this->watchlist_size; i++)
		{
			read >> Footage;
			Watchlist.push_back(Footage);
		}
		read.close();
		return Watchlist;
	}
	else
	{
		std::vector<footage> watchlist;
		if (this->watchlist_size == 0)
			return watchlist;
		std::ifstream file{ this->mylistLocation };
		std::string html_line;
		std::string title, section, preview;
		int acces_count;
		std::string date_string;

		//ignoring irrelevant lines
		for (int i = 0; i < 14; i++)
		{
			getline(file, html_line);
		}

		while (html_line == "<tr>") {
			getline(file, html_line);
			title = html_line.substr(entity_border_right, html_line.size() - entity_border_left);
			getline(file, html_line);
			section = html_line.substr(entity_border_right, html_line.size() - entity_border_left);
			getline(file, html_line);
			date_string = html_line.substr(entity_border_right, html_line.size() - entity_border_left);
			getline(file, html_line);
			acces_count = std::stoi(html_line.substr(entity_border_right, html_line.size() - entity_border_left));
			getline(file, html_line);
			preview = html_line.substr(entity_border_right, html_line.size() - entity_border_left);

			int day = 0, month = 0, year = 0;
			auto digit = date_string.begin();
			//getting the digits for the date
			while (*digit != '-')
			{
				day = day * 10 + *digit - '0';
				digit++;
			}
			digit++;
			while (*digit != '-')
			{
				month = month * 10 + *digit - '0';
				digit++;
			}
			digit++;
			while (digit != date_string.end())
			{
				year = year * 10 + *digit - '0';
				digit++;
			}
			date Date{ day,month,year };
			footage Footage{ title,section,Date,acces_count,preview };
			watchlist.push_back(Footage);

			getline(file, html_line);
			getline(file, html_line);
		}
		return watchlist;
	}
}

void file_repo::set_file_location(char* file_location)
{
	//inserts the file location into memory
	if (strcmp(file_location, "") == 0)
		throw RepositoryExceptions("You entered an empty file location");
	strcpy(this->file_location, file_location);
}
void file_repo::write_container_to_file(std::vector<footage> Container)
{
	//updates the content of the file
	if (strcmp(this->file_location, "") == 0)
		throw RepositoryExceptions("You forgot to enter a file location");
	std::ofstream write;
	write.open(this->file_location);
	write << this->number_of_footages << std::endl;
	if (Container.empty())
		return;
	for (auto Footage = Container.begin(); Footage != Container.end(); Footage++)
	{
		write << *Footage;
	}
	write.close();
}
int file_repo::get_count()
{
	//returns the number of footages 
	return this->number_of_footages;
}

memory_repo::memory_repo()
{
	this->container.clear();
	strcpy(this->mylistLocation, "");
	strcpy(this->mylistMode, "");
	this->watchlist_size = 0;
}
void memory_repo::add(footage* Footage)
{
	this->container.push_back(*Footage);
}
void memory_repo::update(std::string title, std::string section, int day, int month, int year, int Acces_count, std::string preview)
{
	int i = 0;
	for (auto Footage : this->container)
	{
		if (Footage.get_title() == title)
		{
			date Date(day, month, year);
			footage Footage(title, section, Date, Acces_count, preview);
			this->container.at(i) = Footage;
		}
	}
}
void memory_repo::remove(std::string title)
{
	auto Footage = this->container.begin();
	while (Footage != this->container.end())
	{
		if (Footage->get_title() == title)
		{
			this->container.erase(Footage);
			return;
		}
		else
			Footage++;
	}
}
void memory_repo::set_myList_location(char* mylistLocation)
{

	strcpy(this->mylistLocation, mylistLocation);
	//iterating the mylistLocation in order to chech whether we have to implement a csv or html
	int i = 0;
	while (mylistLocation[i] != '.')
		i++;
	i++;
	if (mylistLocation[i] == 'c')
	{
		//that means we have a csv file
		strcpy(this->mylistMode, "csv");
	}
	else
	{
		//if we're here, we have to implement a html file
		strcpy(this->mylistMode, "html");
	}
}
void memory_repo::set_mylist_mode(char* mode)
{
	//used for initialising the file mode for mylist
	strcpy(this->mylistMode, mode);
}
void memory_repo::open_mylist()
{
	if (strcmp(this->mylistMode, "csv") == 0)
		ShellExecuteA(NULL, NULL, "notepad.exe", this->mylistLocation, NULL, SW_SHOWNORMAL);
	else
		ShellExecuteA(NULL, NULL, "chrome.exe", this->mylistLocation, NULL, SW_SHOWMAXIMIZED);
}

std::vector<footage> memory_repo::get_watchlist()
{
	//opening the file accordingly
	if (strcmp(this->mylistMode, "csv") == 0)
	{
		//reading the csv file
		std::ifstream read{ this->mylistLocation };

		std::vector <footage> Watchlist;
		int i;
		footage Footage{};
		for (i = 0; i < this->watchlist_size; i++)
		{
			read >> Footage;
			Watchlist.push_back(Footage);
		}
		read.close();
		return Watchlist;
	}
	else
	{
		std::vector<footage> watchlist;
		if (this->watchlist_size == 0)
			return watchlist;
		std::ifstream file{ this->mylistLocation };
		std::string html_line;
		std::string title, section, preview;
		int acces_count;
		std::string date_string;

		//ignoring irrelevant lines
		for (int i = 0; i < 14; i++)
		{
			getline(file, html_line);
		}

		while (html_line == "<tr>") {
			getline(file, html_line);
			title = html_line.substr(entity_border_right, html_line.size() - entity_border_left);
			getline(file, html_line);
			section = html_line.substr(entity_border_right, html_line.size() - entity_border_left);
			getline(file, html_line);
			date_string = html_line.substr(entity_border_right, html_line.size() - entity_border_left);
			getline(file, html_line);
			acces_count = std::stoi(html_line.substr(entity_border_right, html_line.size() - entity_border_left));
			getline(file, html_line);
			preview = html_line.substr(entity_border_right, html_line.size() - entity_border_left);

			int day = 0, month = 0, year = 0;
			auto digit = date_string.begin();
			//getting the digits for the date
			while (*digit != '-')
			{
				day = day * 10 + *digit - '0';
				digit++;
			}
			digit++;
			while (*digit != '-')
			{
				month = month * 10 + *digit - '0';
				digit++;
			}
			digit++;
			while (digit != date_string.end())
			{
				year = year * 10 + *digit - '0';
				digit++;
			}
			date Date{ day,month,year };
			footage Footage{ title,section,Date,acces_count,preview };
			watchlist.push_back(Footage);

			getline(file, html_line);
			getline(file, html_line);
		}
		return watchlist;
	}
}
std::vector<footage> memory_repo::get_container()
{
	return this->container;
}
void memory_repo::add_to_watchlist(std::string title)
{
	//searches for the specific footage and adds it to the watchlist
	std::vector<footage> Container = this->get_container();
	std::vector<footage> Watchlist = this->get_watchlist();
	bool found = 0;
	for (auto element : Container)
	{
		if (element.get_title() == title)
		{
			Watchlist.push_back(element);
			this->watchlist_size++;
			found = 1;
		}
	}
	this->write_watchlist_to_file(Watchlist);
	if (!found)
		throw RepositoryExceptions("The footage was not found!");
}
void memory_repo::write_watchlist_to_file(std::vector<footage> Watchlist)
{
	if (strcmp(this->mylistLocation, "") == 0)
		throw RepositoryExceptions("You forgot to enter a myList location");
	else if ((strcmp(this->mylistMode, "csv") != 0) && (strcmp(this->mylistMode, "html") != 0))
		throw RepositoryExceptions("Invalid myList location, neither html nor csv");
	if (strcmp(this->mylistMode, "csv") == 0)
	{
		//write in csv format
		std::ofstream write(this->mylistLocation);
		for (auto Footage : Watchlist)
		{
			write << Footage;
		}
		write.close();
	}
	else
	{
		std::ofstream file{ this->mylistLocation };
		file << "<!DOCTYPE html>\n<html>\n<head>\n<title>Footages</title>\n</head><body>\n<table border='1'>\n<tr>\n<td>Title</td>\n<td>Section</td>\n<td>Date</td>\n<td>AccesCount</td>\n<td>Preview</td>\n</tr>\n";
		for (auto Footage : Watchlist) {
			file << "<tr>\n";
			file << "<td>" + Footage.get_title() << "</td>\n";
			file << "<td>" + Footage.get_section() << "</td>\n";
			date Date = Footage.get_date();
			file << "<td>" << Date.get_day() << "-" << Date.get_month() << "-" << Date.get_year() << "</td>\n";
			file << "<td>" << Footage.get_acces_count() << "</td>\n";
			file << "<td>" + Footage.get_preview() << "</td>\n";
			file << "</tr>\n";
		}
		file << "</table>\n";
		file << "</body>\n";
		file << "</hmtl>";

		file.close();
	}
}

int memory_repo::get_count()
{
	return this->container.size();
}