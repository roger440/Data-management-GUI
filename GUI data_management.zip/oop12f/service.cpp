#include "service.h"
#include<iostream>
#define year_relevance 1990
#define month_relevance 4
#include "validator.h"
service::service(repo* Repo)
{
	this->Repo = Repo;
	this->mode = "";
	this->my_list_index = 0;
}
void service::set_mode(std::string mode)
{
	this->mode = mode;
}
footage service::get_next_footage()
{
	if (this->mode != "mode B")
		throw ServiceExceptions("You can't get the next footage through this mode");
	std::vector <footage > Container = this->Repo->get_container();
	this->my_list_index++;
	if (this->my_list_index > Container.size())
		this->my_list_index = 1;
	return Container.at(this->my_list_index - 1);
}
void service::add(data_type* Footage)
{
	if (this->mode != "mode A")
		throw ServiceExceptions("Can't add in this mode");
	//calls repo in order to add a footage
	date Date = Footage->get_date();
	int year = Date.get_year();
	int month = Date.get_month();


	validator Validator;
	Validator.validate_footage(*Footage);
	this->Repo->add(Footage);
}
void service::set_myList_location(char* mylistLocation)
{
	this->Repo->set_myList_location(mylistLocation);
}

void service::update(std::string title, std::string section, int day, int month, int year, int Acces_count, std::string preview)
{
	if (this->mode != "mode A")
		throw ServiceExceptions("Can't update in this mode");
	//calls repo in order to update one footage
	this->Repo->update(title, section, day, month, year, Acces_count, preview);
}

void service::remove(std::string title)
{
	if (this->mode != "mode A")
		throw ServiceExceptions("Can't remove in this mode");
	//calls repo in order to remove a footage
	this->Repo->remove(title);
}

void service::add_to_watchlist(std::string Title)
{
	//calls the repo function which adds a footage to the watchlist
	this->Repo->add_to_watchlist(Title);
}
std::vector<footage> service::get_container()
{
	//calls the repo function which gets the data
	return this->Repo->get_container();
}
std::vector<footage> service::get_watchlist()
{
	if (this->mode != "mode B")
		throw ServiceExceptions("You can't acces mylist through this mode");
	//calls the repo function which gets the watchlist
	return this->Repo->get_watchlist();
}
std::string service::get_mode()
{
	return this->mode;
}
void service::set_file_location(char* file_location)
{
	this->Repo->set_file_location(file_location);
}
int service::get_count()
{
	return this->Repo->get_count();
}
void service::open_mylist()
{
	if (this->mode != "mode B")
		throw ServiceExceptions("You can't open mylist through this mode");
	this->Repo->open_mylist();
}
void service::save_to_watchlist()
{
	if (this->mode != "mode B")
		throw ServiceExceptions("You can't add to mylist through this mode");
	std::vector <footage> Container = this->get_container();
	std::string Title = Container.at(this->my_list_index - 1).get_title();
	this->add_to_watchlist(Title);
}
