#include "domain.h"
#include <vector>
#define TITLE_COMPONENT_INDEX 0
#define SECTION_COMPONENT_INDEX 1
#define DATE_COMPONENT_INDEX 2
#define ACCES_COUNT_COMPONENT_INDEX 3
#define PREVIEW_COMPONENT_INDEX 4


footage::footage(std::string title, std::string section, date Date, int acces_count, std::string preview)
{
	//the constructor of footage which takes all the components

	this->title = title;
	;
	this->section = section;

	this->Date = Date;
	this->acces_count = acces_count;

	this->preview = preview;
}
date::date(int day, int month, int year)
{
	//creates an instance of a date
	this->day = day;
	this->month = month;
	this->year = year;
}
footage::footage()
{
	// creates an instance of footage with no parameters

	this->section = "";
	int day = 0, month = 0, year = 0;
	this->Date = date(day, month, year);
	this->acces_count = acces_count;

	this->preview = "";
}


std::string footage::get_title()
{
	//returns the title of a footage
	return this->title;
}

std::string footage::get_section()
{
	//returns the section of a footage
	return this->section;
}

date footage::get_date()
{
	//returns a pointer to all footages
	return this->Date;
}

int footage::get_acces_count()
{
	//returns the acces count of a footage
	return this->acces_count;
}

std::string footage::get_preview()
{
	//returns the preview of a footage
	return this->preview;
}

date::date()
{
	this->day = 0;
	this->month = 0;
	this->year = 0;
}

//getters for the date
int date::get_day()
{
	return this->day;
}
int date::get_month()
{
	return this->month;
}
int date::get_year()
{
	return this->year;
}
std::istream& operator>>(std::istream& inputStream, footage& Footage)
{
	//overwrites the >> operator in order to read a footage correctly
	std::string line;
	getline(inputStream, line);
	std::stringstream stringStream(line);
	std::vector<std::string> tokens;
	std::string token;
	char delimiter = ',';
	while (getline(stringStream, token, delimiter))
	{
		tokens.push_back(token);
	}
	//removes the unneccesary space before the title
	if (*tokens[TITLE_COMPONENT_INDEX].begin() == ' ')
	{
		tokens[TITLE_COMPONENT_INDEX].erase(tokens[TITLE_COMPONENT_INDEX].begin());
	}
	if (*tokens[SECTION_COMPONENT_INDEX].begin() == ' ')
	{
		tokens[SECTION_COMPONENT_INDEX].erase(tokens[SECTION_COMPONENT_INDEX].begin());
	}
	tokens[PREVIEW_COMPONENT_INDEX].erase(tokens[PREVIEW_COMPONENT_INDEX].begin());
	Footage.title = tokens[TITLE_COMPONENT_INDEX];
	Footage.section = tokens[SECTION_COMPONENT_INDEX];
	std::string Date = tokens[DATE_COMPONENT_INDEX];
	Footage.preview = tokens[PREVIEW_COMPONENT_INDEX];
	auto date_digit = Date.begin();
	int day = 0;
	int month = 0;
	int year = 0;
	date_digit++;
	//getting the date's numbers
	while (*date_digit != '-')
	{
		day = day * 10 + *date_digit - '0';
		date_digit++;
	}
	date_digit++;
	while (*date_digit != '-')
	{
		month = month * 10 + *date_digit - '0';
		date_digit++;
	}
	date_digit++;
	while (date_digit != Date.end() && *date_digit != ' ')
	{
		year = year * 10 + *date_digit - '0';
		date_digit++;
	}
	date DATE(day, month, year);
	Footage.Date = DATE;
	int acces_count = 0;
	std::string Acces_count = tokens[ACCES_COUNT_COMPONENT_INDEX];
	Acces_count.erase(Acces_count.begin());
	auto digit_of_acces_count = Acces_count.begin();
	while (digit_of_acces_count != Acces_count.end())
	{
		acces_count = acces_count * 10 + *digit_of_acces_count - '0';
		digit_of_acces_count++;
	}
	Footage.acces_count = acces_count;
	return inputStream;

}
std::ostream& operator<<(std::ostream& OutputStream, footage& Footage)
{
	//overwrite the << operator in order to print a footage directly
	date Date = Footage.get_date();
	OutputStream << Footage.get_title() << ", " << Footage.get_section() << ", " << Date.get_day() << "-" << Date.get_month() << "-" << Date.get_year() << ", " << Footage.get_acces_count() << ", " << Footage.get_preview() << std::endl;
	return OutputStream;
}