#include "FootageGui.h"

FootageGui::FootageGui(QWidget *parent)
	: QMainWindow(parent)
{
	ui.setupUi(this);
}
