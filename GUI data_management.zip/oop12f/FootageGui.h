#pragma once

#include <QtWidgets/QMainWindow>
#include "ui_FootageGui.h"

class FootageGui : public QMainWindow
{
	Q_OBJECT

public:
	FootageGui(QWidget *parent = Q_NULLPTR);

private:
	Ui::FootageGuiClass ui;
};
