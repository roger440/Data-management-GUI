#pragma once
#include "repo.h"
class service
{
private:
	repo* Repo;
	std::string mode;
	int my_list_index;
public:
	service(repo* Repo);

	void add(data_type* Footage);
	void add_to_watchlist(std::string Title);
	void update(std::string title, std::string section, int day, int month, int year, int Acces_count, std::string preview);
	void remove(std::string title);
	std::vector<footage> get_container();
	std::vector<footage> get_watchlist();
	void set_file_location(char* file_location);
	void set_myList_location(char* mylistLocation);
	void save_to_watchlist();
	int get_count();
	footage get_next_footage();
	std::string get_mode();
	void set_mode(std::string mode);
	void open_mylist();
};
