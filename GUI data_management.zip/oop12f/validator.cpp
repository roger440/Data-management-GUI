#include "validator.h"
validator::validator()
{}
void validator::validate_footage(footage Footage)
{
	if (Footage.get_title() == "")
		this->error_message += "You entered an empty title";
	if (Footage.get_section() == "")
		this->error_message += "You entered an empty section";
	if (Footage.get_preview() == "")
		this->error_message += "You entered an empty preview";
	if (Footage.get_acces_count() < 0)
		this->error_message += "You entered a negative number";

	if (this->error_message.size() != 0)
		throw ValidatorExeptions(this->error_message);
}
