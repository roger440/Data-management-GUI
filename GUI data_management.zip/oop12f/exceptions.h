#include <iostream>

class MyExceptions : public std::exception {

	virtual std::string throw_error()  throw() = 0;
};


class RepositoryExceptions : public MyExceptions {
public:
	std::string error_message;

	virtual std::string throw_error()  throw() override 
	{
		return "Repository Error: " + error_message + "\n";
	}

public:
	RepositoryExceptions(const std::string Error_message)
	{
		this->error_message = Error_message;
	}
};

class ServiceExceptions : public MyExceptions {
public:
	std::string error_message;

	virtual std::string throw_error()  throw() override
	{
		return "Service Error: " + error_message + "\n";
	}

public:
	ServiceExceptions(const std::string error_message)
	{
		this->error_message = error_message;
	}
};

class ValidatorExeptions : public MyExceptions {
public:
	std::string error_message;
	virtual std::string throw_error()  throw() override
	{
		return "Validation Error: " + error_message + "\n";
	}
public:
	ValidatorExeptions(const std::string error_message)
	{
		this->error_message = error_message;
	}
};
