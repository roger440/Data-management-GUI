#pragma once
#include "exceptions.h"
#include "domain.h"
class validator
{
private:
	std::string error_message;
public:
	validator();
	void validate_footage(footage Footage);
};