#include "oop12.h"

oop12::oop12(QWidget *parent)
    : QMainWindow(parent)
{
    ui.setupUi(this);
}
