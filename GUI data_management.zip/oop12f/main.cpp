#include "oop12.h"
#include <QtWidgets/QApplication>
#include "service.h"
#include "GUI.h"
#define CONFIGURATION_MAX_SIZE 50
int main(int argc, char *argv[])
{
	QApplication a(argc, argv);
	//this is the file the configuration is read from
	//the first element is either "memory" or "file"
	//the second element is either "csv" or "html" for the "mylist"
	//by default, the app starts in mode A
	//
	//
	//this is the file the configuration is read from
	std::ifstream read("configuration");
	//
	char repo_mode[CONFIGURATION_MAX_SIZE];
	char mylist_mode[CONFIGURATION_MAX_SIZE];
	read >> repo_mode>>mylist_mode;
	//in the program, the accepted modes are "mode A" or "mode B"
	read.close();
	if (strcmp(repo_mode, "memory")==0)
	{
		memory_repo Repo{};
		Repo.set_mylist_mode(mylist_mode);
		service Service(&Repo);
		GUI gui(&Service);
		gui.show();
		return a.exec();
	}
	else
	{
		file_repo Repo{};
		Repo.set_mylist_mode(mylist_mode);
		//"ovi" is the initial file location from which we read data at the beginning
		//please also put the number of the footages in the file, at the beginning
		Repo.set_file_location("ovi");
		service Service(&Repo);
		GUI gui{ &Service };
		gui.show();

		return a.exec();
	}


}
