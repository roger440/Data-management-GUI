#include "GUI.h"
#include "qlayout.h"
#include "qformlayout.h"
#include "qgridlayout.h"
GUI::GUI(service* Service)
{
	this->Service = Service;
	this->Service->set_mode("mode A");
	this->initGUI();
	this->populate_list();
	this->connect_signals_and_slots();
}
void GUI::filter()
{
	this->footage_widget->clear();
	std::vector<footage> container = this->Service->get_container();
	std::string section = this->section_line->text().toStdString();
	int Acces_count = 0;
	std::string acces_count_string = this->acces_count_line->text().toStdString();
	auto digit = acces_count_string.begin();
	while (digit != acces_count_string.end())
	{
		Acces_count = Acces_count * 10 + *digit - '0';
		digit++;
	}
	for (auto Footage : container)
	{
		if (Footage.get_section() == section && Footage.get_acces_count() < Acces_count)
		{
			this->footage_widget->addItem(QString::fromStdString(Footage.get_title()));
		}
	}
}
void GUI::save()
{
	this->Service->save_to_watchlist();
}
void GUI::populate_list()
{
	std::string Mode = this->Service->get_mode();
	if (Mode != "mode A")
		throw("No acces");
	this->footage_widget->clear();
	std::vector<footage> Container = this->Service->get_container();
	for (auto Footage : Container)
	{
		date Date = Footage.get_date();
		this->footage_widget->addItem(QString::fromStdString(Footage.get_title()));
	}
}
void GUI::set_mode()
{
	std::string mode = this->mode_line->text().toStdString();
	this->Service->set_mode(mode);
}
int GUI::get_selected_index()
{
	QModelIndexList selected_indexes = this->footage_widget->selectionModel()->selectedIndexes();
	if (selected_indexes.size() == 0)
	{
		this->title_line->clear();
		this->section_line->clear();
		this->date_line->clear();
		this->preview_line->clear();
		this->acces_count_line->clear();
		return -1;
	}
	int selected_index = selected_indexes.at(0).row();
	return selected_index;
}
void GUI::add_footage()
{
	std::string title = this->title_line->text().toStdString();
	std::string section = this->section_line->text().toStdString();
	std::string preview = this->preview_line->text().toStdString();
	std::string date_string= this->date_line->text().toStdString();

	auto digit = date_string.begin();
	int day = 0, month = 0, year = 0;
	while (*digit != '-')
	{
		day = day * 10 + *digit - '0';
		digit++;
	}
	digit++;
	while (*digit != '-')
	{
		month = month * 10 + *digit - '0';
		digit++;
	}
	digit++;
	while (digit != date_string.end())
	{
		year = year * 10 + *digit - '0';
		digit++;
	}
	date Date(day, month, year);
	int Acces_count = 0;
	std::string acces_count_string = this->acces_count_line->text().toStdString();
	digit = acces_count_string.begin();
	while(digit!=acces_count_string.end())
	{
		Acces_count = Acces_count * 10 + *digit - '0';
		digit++;
	}
	footage Footage(title, section, Date, Acces_count, preview);
	this->Service->add(&Footage);
	this->populate_list();
}
void GUI::update_footage()
{
	std::string title = this->title_line->text().toStdString();
	std::string section = this->section_line->text().toStdString();
	std::string preview = this->preview_line->text().toStdString();
	std::string date_string = this->date_line->text().toStdString();

	auto digit = date_string.begin();
	int day = 0, month = 0, year = 0;
	while (*digit != '-')
	{
		day = day * 10 + *digit - '0';
		digit++;
	}
	digit++;
	while (*digit != '-')
	{
		month = month * 10 + *digit - '0';
		digit++;
	}
	digit++;
	while (digit != date_string.end())
	{
		year = year * 10 + *digit - '0';
		digit++;
	};
	int Acces_count = 0;
	std::string acces_count_string = this->acces_count_line->text().toStdString();
	digit = acces_count_string.begin();
	while (digit != acces_count_string.end())
	{
		Acces_count = Acces_count * 10 + *digit - '0';
		digit++;
	}

	this->Service->update(title,section, day,month,year ,Acces_count, preview);
	this->populate_list();
}
void GUI::delete_footage()
{
	std::string title = this->title_line->text().toStdString();
	this->Service->remove(title);
	this->populate_list();
}
void GUI::next()
{
	this->footage_widget->clear();
	footage Footage = this->Service->get_next_footage();
	this->footage_widget->addItem(QString::fromStdString(Footage.get_title()));

}
void GUI::connect_signals_and_slots()
{
	QObject::connect(this->footage_widget, &QListWidget::itemSelectionChanged, [this]() {
		int selected_index = this->get_selected_index();
		if (selected_index < 0)
			return;
		footage Footage = this->Service->get_container()[selected_index];
		this->section_line->setText(QString::fromStdString(Footage.get_section()));
		this->preview_line->setText(QString::fromStdString(Footage.get_preview()));
		this->title_line->setText(QString::fromStdString(Footage.get_title()));

		int Acces_count = Footage.get_acces_count();
		char acces_count[100];
		itoa(Acces_count, acces_count, 10);
		std::string acces_count_string(acces_count);

		this->acces_count_line->setText(QString::fromStdString(acces_count_string));

		date Date = Footage.get_date();

		int Day = Date.get_day();
		char day[100];
		itoa(Day, day, 10);
		std::string day_string(day);

		int Month = Date.get_month();
		char month[100];
		itoa(Month, month, 10);
		std::string month_string(month);

		int Year = Date.get_year();
		char year[100];
		itoa(Year, year, 10);
		std::string year_string(year);

		this->date_line->setText(QString::fromStdString(day_string + "-" + month_string + "-" + year_string));
	});


		QObject::connect(this->add_button, &QPushButton::clicked, this, &GUI::add_footage); 
		QObject::connect(this->update_button, &QPushButton::clicked, this, &GUI::update_footage);
		QObject::connect(this->delete_button, &QPushButton::clicked, this, &GUI::delete_footage);
		QObject::connect(this->list_button, &QPushButton::clicked, this, &GUI::populate_list);
		QObject::connect(this->set_mode_button, &QPushButton::clicked, this, &GUI::set_mode);
		QObject::connect(this->next_button, &QPushButton::clicked, this, &GUI::next);
		QObject::connect(this->save_button, &QPushButton::clicked, this, &GUI::save);
		QObject::connect(this->mylist_button, &QPushButton::clicked, this, &GUI::open_mylist);
		QObject::connect(this->mylist_location_button, &QPushButton::clicked, this, &GUI::set_mylist_location);
		QObject::connect(this->filter_button, &QPushButton::clicked, this, &GUI::filter);

}
void GUI::open_mylist()
{
	this->Service->open_mylist();
}
void GUI::set_mylist_location()
{
	std::string location = this->my_list_location_line->text().toStdString();
	char Location[100];
	int i = 0;
	for (auto character : location)
	{
		Location[i] = character;
		i++;
	}
	Location[i] = '\0';
	this->Service->set_myList_location(Location);
}
void GUI::initGUI()
{
	this->footage_widget = new QListWidget{};
	this->mode_b_widget=new QListWidget{};
	this->title_line = new QLineEdit{};
	this->preview_line= new QLineEdit{};
	this->date_line = new QLineEdit{};
	this->acces_count_line = new QLineEdit{};
	this->mode_line = new QLineEdit{};
	this->section_line = new QLineEdit{};
	this->my_list_location_line = new QLineEdit{};
	this->add_button = new QPushButton{"add"};
	this->next_button= new QPushButton{ "next" };
	this->save_button= new QPushButton{ "save" };
	this->mylist_location_button=new QPushButton{ "set_mylist_location" };
	this->filter_button=new  QPushButton{ "filter" };
	this->set_mode_button=new QPushButton{"Set mode"};
	this->update_button = new QPushButton{"update"};
	this->delete_button = new QPushButton{"delete"};
	this->list_button=new QPushButton{ "list" };
	this->mylist_button = new QPushButton{ "mylist" };

	QVBoxLayout* main_layout = new QVBoxLayout{this};

	main_layout->addWidget(this->footage_widget);

	QFormLayout* footage_details = new QFormLayout{ this };
	footage_details->addRow("Mode", this->mode_line);

	footage_details->addRow("Title",this->title_line);
	footage_details->addRow("Section", this->section_line);
	footage_details->addRow("Date", this->date_line);
	footage_details->addRow("Acces_Count", this->acces_count_line);
	footage_details->addRow("Preview", this->preview_line);
	footage_details->addRow("myList location", this->my_list_location_line);

	main_layout->addLayout(footage_details);


	QGridLayout* buttons_layout = new QGridLayout{};
	buttons_layout->addWidget(this->add_button, 1, 0);
	buttons_layout->addWidget(this->update_button, 1, 1);
	buttons_layout->addWidget(this->delete_button, 1, 2);
	buttons_layout->addWidget(this->list_button, 1, 3);
	buttons_layout->addWidget(this->set_mode_button, 0, 1);
	buttons_layout->addWidget(this->mylist_location_button, 0, 2);
	buttons_layout->addWidget(this->next_button, 2, 0);
	buttons_layout->addWidget(this->save_button, 2, 1);
	buttons_layout->addWidget(this->filter_button, 2, 2);
	buttons_layout->addWidget(this->mylist_button, 2, 3);


	main_layout->addLayout(buttons_layout);

}