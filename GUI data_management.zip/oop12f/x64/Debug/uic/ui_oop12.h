/********************************************************************************
** Form generated from reading UI file 'oop12.ui'
**
** Created by: Qt User Interface Compiler version 5.14.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_OOP12_H
#define UI_OOP12_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_oop12Class
{
public:
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QWidget *centralWidget;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *oop12Class)
    {
        if (oop12Class->objectName().isEmpty())
            oop12Class->setObjectName(QString::fromUtf8("oop12Class"));
        oop12Class->resize(600, 400);
        menuBar = new QMenuBar(oop12Class);
        menuBar->setObjectName(QString::fromUtf8("menuBar"));
        oop12Class->setMenuBar(menuBar);
        mainToolBar = new QToolBar(oop12Class);
        mainToolBar->setObjectName(QString::fromUtf8("mainToolBar"));
        oop12Class->addToolBar(mainToolBar);
        centralWidget = new QWidget(oop12Class);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        oop12Class->setCentralWidget(centralWidget);
        statusBar = new QStatusBar(oop12Class);
        statusBar->setObjectName(QString::fromUtf8("statusBar"));
        oop12Class->setStatusBar(statusBar);

        retranslateUi(oop12Class);

        QMetaObject::connectSlotsByName(oop12Class);
    } // setupUi

    void retranslateUi(QMainWindow *oop12Class)
    {
        oop12Class->setWindowTitle(QCoreApplication::translate("oop12Class", "oop12", nullptr));
    } // retranslateUi

};

namespace Ui {
    class oop12Class: public Ui_oop12Class {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_OOP12_H
